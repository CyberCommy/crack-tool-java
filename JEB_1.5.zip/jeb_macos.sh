#!/bin/bash

if [ -z "$JAVA_HOME" ]; then
  JAVA=`which java`
else
  JAVA=$JAVA_HOME/bin/java
fi

if [ ! -f "$JAVA" ]; then
  echo "JEB requires a Java runtime environment, please install one."
  exit -1
fi

cd `dirname $0`
SCRIPTDIR=`pwd`
cd - >/dev/null

SWTLIB=$SCRIPTDIR/bin/swt.jar

if [ ! -f "$SWTLIB" ]; then
  cp $SCRIPTDIR/swt/swt-4.7.2-cocoa-macosx-x86_64.jar $SWTLIB
fi

JEBSERVER=$SCRIPTDIR/bin/jebserver.jar

$JAVA -Xmx4G -XX:-UseParallelGC -XX:MinHeapFreeRatio=15 -XX:MaxHeapFreeRatio=30 -jar $JEBSERVER "$@"
